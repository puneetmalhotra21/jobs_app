function callRouter(paramid) {
  document.getElementById(paramid).click();
}

export {callRouter};